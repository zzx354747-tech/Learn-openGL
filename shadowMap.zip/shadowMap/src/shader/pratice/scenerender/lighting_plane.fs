#version 330 core

in VS_OUT {
    vec3 FragPos;
    vec3 Normal;
    vec2 TexCoords;
    vec4 FragPosLightSpace;
} fs_in;


out vec4 FragColor;

struct PointLight {
    vec3 position;
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    float constant;
    float linear;
    float quadratic;
};

struct Sun {
    vec3 direction;
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
};

struct FlashLight {
    vec3 position;
    vec3 direction;
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    float constant;
    float linear;
    float quadratic;
    float cutOff;
    float outerCutOff;
};

uniform sampler2D texture1;
// 接收阴影贴图
uniform sampler2D shadowMap;

uniform PointLight pointLight;
uniform Sun sun;
uniform FlashLight flashLight;
uniform vec3 viewPos;
uniform bool enablePointLight;
uniform bool enableDirectionalLight;
uniform bool enableFlashlight;

float ShadowCalculation(vec4 fragPosLightSpace)
{
    // 将片段位置从裁剪空间转换到[0,1]范围内，告诉去哪里采样阴影贴图
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;

     // 处理视野外的片段，防止出现不正确的阴影
    if (projCoords.z > 1.0)
        return 0.0;

    // 获取当前片段在阴影贴图中的深度
    float closestDepth = texture(shadowMap, projCoords.xy).r;
    float currentDepth = projCoords.z;

    // 计算阴影
    float shadow = currentDepth - 0.005 > closestDepth ? 1.0 : 0.0;
    return shadow;
}

vec3 calcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 baseColor)
{
    vec3 lightDir = normalize(light.position - fragPos);
    vec3 reflectDir = reflect(-lightDir, normal);
    float diff = max(dot(normal, lightDir), 0.0);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 16.0);
    float distance = length(light.position - fragPos);
    float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * distance * distance);
    return light.ambient * baseColor + (light.diffuse * diff * baseColor + light.specular * spec) * attenuation;
}

vec3 calcSun(Sun light, vec3 normal, vec3 viewDir, vec3 baseColor)
{
    vec3 lightDir = normalize(-light.direction);
    vec3 reflectDir = reflect(-lightDir, normal);
    float diff = max(dot(normal, lightDir), 0.0);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 16.0);

    float shadowStrength = 0.8; // 阴影强度，可以根据需要调整

    float shadow = ShadowCalculation(fs_in.FragPosLightSpace);
    
    shadow *= shadowStrength; // 将阴影强度应用到阴影值上

    // 将阴影应用到漫反射和镜面反射上
    light.diffuse *= (1.0 - shadow);
    light.specular *= (1.0 - shadow);

    return light.ambient * baseColor + light.diffuse * diff * baseColor + light.specular * spec;
}

vec3 calcFlashLight(FlashLight light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 baseColor)
{
    vec3 lightDir = normalize(light.position - fragPos);
    vec3 reflectDir = reflect(-lightDir, normal);
    float diff = max(dot(normal, lightDir), 0.0);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 16.0);
    float distance = length(light.position - fragPos);
    float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * distance * distance);
    float theta = dot(lightDir, normalize(-light.direction));
    float epsilon = light.cutOff - light.outerCutOff;
    float intensity = clamp((theta - light.outerCutOff) / epsilon, 0.0, 1.0);
    return light.ambient * baseColor + (light.diffuse * diff * baseColor + light.specular * spec) * attenuation * intensity;
}

void main()
{
    vec3 baseColor = texture(texture1, fs_in.TexCoords).rgb;
    vec3 normal = normalize(fs_in.Normal);
    vec3 viewDir = normalize(viewPos - fs_in.FragPos);
    vec3 result = vec3(0.0);
    if (enablePointLight)
        result += calcPointLight(pointLight, normal, fs_in.FragPos, viewDir, baseColor);
    if (enableDirectionalLight)
        result += calcSun(sun, normal, viewDir, baseColor);
    if (enableFlashlight)
        result += calcFlashLight(flashLight, normal, fs_in.FragPos, viewDir, baseColor);
    FragColor = vec4(result, 1.0);
}
